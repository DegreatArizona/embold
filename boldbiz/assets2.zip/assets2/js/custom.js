(function($) {

	'use strict';

	// Mean Menu
	$('.mean-menu').meanmenu({
		meanScreenWidth: "992"
	}); 

	// Others Option For Responsive JS
	$(".others-option-for-responsive .dot-menu").on("click", function(){
		$(".others-option-for-responsive .container .container").toggleClass("active");
	});


	// Sticky, Go To Top JS
	$(window).on('scroll', function() { 
		// Header Sticky JS 
		if ($(this).scrollTop() >150){  
			$('.navbar-area').addClass("is-sticky");
		}
		else{
			$('.navbar-area').removeClass("is-sticky"); 
		};
	});

	// aos 
	AOS.init({
		disable: function() {
			var maxWidth = 992;
			return window.innerWidth < maxWidth;
		}
	});


	// Great Places Slider
	$('.great-places-slider').owlCarousel({
		loop: true,
		margin: 25,
		nav: true,
		dots: false,
		autoplay: true,
		smartSpeed: 1000,
		autoplayHoverPause: true,
		navText: [
			'<i class="flaticon-left-arrow"></i>', 
			'<i class="flaticon-right-arrow-angle"></i>',    
		],
		responsivee:{
			0:{
				items:1
			},
			570:{
				items:1
			},
			768:{
				items:2
			},
			992:{
				items:3
			},
			1200:{
				items:3
			}
		}
	});

	// Great Places Two Slider
	$('.great-places-two-slider').owlCarousel({
		loop: true,
		margin: 20,
		nav: true,
		dots: false,
		autoplay: true,
		smartSpeed: 1000,
		autoplayHoverPause: true,
		navText: [
			'<i class="flaticon-left-arrow"></i>', 
			'<i class="flaticon-right-arrow-angle"></i>',    
		],
		responsivee:{
			0:{
				items:1
			},
			570:{
				items:1
			},
			768:{
				items:2
			},
			992:{
				items:3
			},
			1200:{
				items:3
			}, 
			1320:{
				items:4
			},
			1700:{
				items:4
			}
		}
	});

	// Popular Destination Slider
	$('.popular-destination-slider').owlCarousel({
		loop: true,
		margin: 0,
		nav: false,
		dots: true,
		autoplay: false,
		smartSpeed: 1000,
		autoplayHoverPause: true,
		center: true,
		onInitialized  : counter,
		onTranslated : counter,
		navText: [
			'<i class="flaticon-left-arrow"></i>', 
			'<i class="flaticon-right-arrow-angle"></i>',    
		],
		responsivee:{
			0:{
				items:1
			},
			768:{
				items:2
			},
			1000:{
				items:2
			},
			1200:{
				items:3
			}
		}
	});
	
	function counter(event) {
		var element   = event.target;       
		var items     = event.item.count;     
		var item      = event.item.index + 1;    
	   
	   if(item > items) {
		 item = item - items
	   }
	   $('#counter').html("<span> "+item+"</span> / "+items)
	}

	// Testimonials Slider
	$('.testimonials-slider').owlCarousel({
		loop: true,
		margin: 25,
		nav: true,
		dots: false,
		autoplay: true,
		smartSpeed: 1000,
		autoplayHoverPause: true,
		navText: [
			'<i class="flaticon-left-arrow"></i>', 
			'<i class="flaticon-right-arrow-angle"></i>',    
		],
		responsivee:{
			0:{
				items:1
			},
			768:{
				items:2
			},
			1000:{
				items:2
			}
		}
	});

	// Great Places Three Slider
	$('.great-places-three-slider').owlCarousel({
		loop: true,
		margin: 25,
		nav: true,
		dots: false,
		autoplay: true,
		smartSpeed: 1000,
		autoplayHoverPause: true,
		navText: [
			'<i class="flaticon-left-arrow"></i>', 
			'<i class="flaticon-right-arrow-angle"></i>',    
		],
		responsivee:{
			0:{
				items:1
			},
			570:{
				items:2
			},
			768:{
				items:2
			},
			1000:{
				items:2
			},
			1200:{
				items:3
			}
		}
	});

	// Beautiful Place Slider
	$('.beautiful-place-slider').owlCarousel({
		loop: true,
		margin: 25,
		nav: true,
		dots: false,
		center: true,
		autoplay: true,
		smartSpeed: 1000,
		autoplayHoverPause: true,
		navText: [
			'<i class="flaticon-left-arrow"></i>', 
			'<i class="flaticon-right-arrow-angle"></i>',    
		],
		responsivee:{
			0:{
				items:1
			},
			570:{
				items:2
			},
			768:{
				items:2
			},
			1000:{
				items:3
			}
		}
	});

	// Testimonials Three Slider 
	$('.testimonials-three-slider').owlCarousel({
		loop: true,
		margin: 25,
		nav: true,
		dots: false,
		autoplay: true,
		smartSpeed: 1000,
		autoplayHoverPause: true,
		navText: [
			'<i class="flaticon-left-arrow"></i>', 
			'<i class="flaticon-right-arrow-angle"></i>',    
		],
		responsivee:{
			0:{
				items:1
			},
			768:{
				items:2
			},
			1000:{
				items:2
			}
		}
	});

	// Persons Travel Slider
	$('.persons-travel-slider').owlCarousel({
		loop: true,
		margin: 25,
		nav: true,
		dots: false,
		autoplay: true,
		smartSpeed: 1000,
		autoplayHoverPause: true,
		navText: [
			'<i class="flaticon-left-arrow"></i>', 
			'<i class="flaticon-right-arrow-angle"></i>',    
		],
		responsivee:{
			0:{
				items:1
			},
			768:{
				items:2
			},
			1000:{
				items:3
			}
		}
	});

	$('.myslider').slick({
		slidesToScroll: 1,
		dots: false,
		arrows: true,
		vertical: true,
		verticalSwiping: true,
		prevArrow: '<div class="slick-prev"></div>',
		nextArrow: '<div class="slick-next"></div>',
	});

	// Partner Logo Slider
	$('.partner-logo-slider').owlCarousel({
		loop: true,
		margin: 25,
		nav: false,
		dots: false,
		autoplay: true,
		smartSpeed: 1000,
		autoplayHoverPause: true,
		navText: [
			'<i class="flaticon-left-arrow"></i>', 
			'<i class="flaticon-right-arrow-angle"></i>',    
		],
		responsivee:{
			0:{
				items:2
			},
			570:{
				items:3
			},
			768:{
				items:4
			},
			992:{
				items:6
			},
			1200:{
				items:6
			}
		}
	});



	// Date Picker JS
	$('#datetimepicker').datepicker({
		weekStart: 0,
		todayBtn: "linked",
		language: "es",
		orientation: "bottom auto",
		keyboardNavigation: false,
		autoclose: true
	});

	// Date Picker JS
	$('#datetimepicker1').datepicker({
		weekStart: 0,
		todayBtn: "linked",
		language: "es",
		orientation: "bottom auto",
		keyboardNavigation: false,
		autoclose: true
	});

	// Date Picker JS
	$('#datetimepicker2').datepicker({
		weekStart: 0,
		todayBtn: "linked",
		language: "es",
		orientation: "bottom auto",
		keyboardNavigation: false,
		autoclose: true
	});

	// Date Picker JS
	$('#datetimepicker3').datepicker({
		weekStart: 0,
		todayBtn: "linked",
		language: "es",
		orientation: "bottom auto",
		keyboardNavigation: false,
		autoclose: true
	});
	
	// Popup Video
	$('.popup-youtube, .popup-vimeo, .popup-gmaps').magnificPopup({ 
		disableOn: 100,
		type: 'iframe',
		mainClass: 'mfp-fade',
		removalDelay: 160,
		preloader: false,

		fixedContentPos: false
	}); 

	// Odometer JS 
	$('.odometer').appear(function(e) {
		var odo = $(".odometer");
		odo.each(function() {
			var countNumber = $(this).attr("data-count");
			$(this).html(countNumber);
		});
	});   

	// Input Plus & Minus Number JS
	$('.input-counter').each(function() {
		var spinner = jQuery(this),
		input = spinner.find('input[type="text"]'),
		btnUp = spinner.find('.plus-btn'),
		btnDown = spinner.find('.minus-btn'),
		min = input.attr('min'),
		max = input.attr('max');
		
		btnUp.on('click', function() {
			var oldValue = parseFloat(input.val());
			if (oldValue >= max) {
				var newVal = oldValue;
			} else {
				var newVal = oldValue + 1;
			}
			spinner.find("input").val(newVal);
			spinner.find("input").trigger("change");
		});
		btnDown.on('click', function() {
			var oldValue = parseFloat(input.val());
			if (oldValue <= min) {
				var newVal = oldValue;
			} else {
				var newVal = oldValue - 1;
			}
			spinner.find("input").val(newVal);
			spinner.find("input").trigger("change");
		});
	}); 

	// Count Time JS
	function makeTimer() {
		var endTime = new Date("november  30, 2025 17:00:00 PDT");			
		var endTime = (Date.parse(endTime)) / 1000;
		var now = new Date();
		var now = (Date.parse(now) / 1000);
		var timeLeft = endTime - now;
		var days = Math.floor(timeLeft / 86400); 
		var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
		var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600 )) / 60);
		var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));
		if (hours < "10") { hours = "0" + hours; }
		if (minutes < "10") { minutes = "0" + minutes; }
		if (seconds < "10") { seconds = "0" + seconds; }
		$("#days").html(days + "<span>Days</span>");
		$("#hours").html(hours + "<span>Hours</span>");
		$("#minutes").html(minutes + "<span>Minutes</span>");
		$("#seconds").html(seconds + "<span>Seconds</span>");
	} 
	setInterval(function() { makeTimer(); }, 300); 

	// Preloader JS
	jQuery(window).on('load',function(){
		jQuery(".preloader").fadeOut(500);
	});

	// Go to Top
	$(function(){
		// Scroll Event
		$(window).on('scroll', function(){
			var scrolled = $(window).scrollTop();
			if (scrolled > 600) $('.go-top').addClass('active');
			if (scrolled < 600) $('.go-top').removeClass('active');
		});  
		// Click Event
		$('.go-top').on('click', function() {
			$("html, body").animate({ scrollTop: "0" },  500);
		}); 
	});


	
})(jQuery);
 
// function to set a given theme/color-scheme
function setTheme(themeName) {
    localStorage.setItem('teva_theme', themeName);
    document.documentElement.className = themeName;
}

// function to toggle between light and dark theme
function toggleTheme() {
    if (localStorage.getItem('teva_theme') === 'theme-dark') {
        setTheme('theme-light');
    } else {
        setTheme('theme-dark');
    }
}

// Immediately invoked function to set the theme on initial load
(function () {
    if (localStorage.getItem('teva_theme') === 'theme-dark') {
        setTheme('theme-dark');
        document.getElementById('slider').checked = false;
    } else {
        setTheme('theme-light');
        document.getElementById('slider').checked = true;
    }
})();