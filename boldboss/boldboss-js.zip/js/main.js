(function() {
	"use strict";

    // My Swiper Partner Slider JS
	var swiper = new Swiper(".mySwiperPartner", {
        slidesPerView: 7,
        spaceBetween: 30,
        loop: true,
        autoplay: {
            delay: 2000,
            disableOnInteraction: false,
        },
        pagination: {
			el: ".swiper-pagination",
			clickable: true,
        },
        breakpoints: {
            0: {
                slidesPerView: 2
            },
            576: {
                slidesPerView: 3
            },
            768: {
                slidesPerView: 5
            },
            992: {
                slidesPerView: 6
            },
            1200: {
                slidesPerView: 7
            }
        }
    });

    // My Swiper Testimonial Slider
    var swiper = new Swiper(".mySwiperTestimonial", {
        spaceBetween: 20,
        loop: true,
        loopFillGroupWithBlank: true,
        autoplay: {
            delay: 2000,
            disableOnInteraction: false,
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        breakpoints: {
            0: {
                slidesPerView: 1
            },
            576: {
                slidesPerView: 1
            },
            768: {
                slidesPerView: 2
            },
            992: {
                slidesPerView: 2
            },
            1200: {
                slidesPerView: 2
            }
        }
    });

    // My Swiper Testimonial Slider
    var swiper = new Swiper(".mySwiperRecent", {
        spaceBetween: 20,
        loop: true,
        autoplay: {
            delay: 2000,
            disableOnInteraction: false,
        },
        navigation: {
            prevEl: ".swiper-button-prev",
            nextEl: ".swiper-button-next",
        },
        breakpoints: {
            0: {
                slidesPerView: 1
            },
            576: {
                slidesPerView: 1
            },
            768: {
                slidesPerView: 2
            },
            992: {
                slidesPerView: 3
            },
            1200: {
                slidesPerView: 3
            }
        }
    });

    // My Swiper Testimonials Area Slider JS
	var swiper = new Swiper(".mySwiperTestimonials", {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: true,
        loopFillGroupWithBlank: true,
        autoplay: {
            delay: 4000,
            disableOnInteraction: false,
        },
        navigation: {
			nextEl: ".swiper-button-prev",
			prevEl: ".swiper-button-next",
        },
    });

    // Get The JS
    try {
        var btnTop = document.querySelector('#scrolltop-arrow');

        var btnReveal = function () { 
            if (window.scrollY > 300) {
            btnTop.classList.add('visible');
            } else {
            btnTop.classList.remove('visible');
            }
        }
    } catch (err) {}
    
    // Navbar JS
    try {
        const nav = document.querySelector('.wile-navbar');
        let navTop = nav.offsetTop;
        
        function fixedNav() {
        if (window.scrollY >= navTop) {
            nav.classList.add('sticky');
        } else {
            nav.classList.remove('sticky');
        }
        }
        window.addEventListener('scroll', fixedNav);
    } catch (err) {}

})()